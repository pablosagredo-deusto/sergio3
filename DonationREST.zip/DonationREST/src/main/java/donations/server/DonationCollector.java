package donations.server;

import donations.serialization.User;


public class DonationCollector {

    private static boolean check = false;
    //here is proccessed info on methods
    public boolean login(String username, String password) {
        synchronized(this) {
                System.out.println("entered in donation collector login method");
                check = true;
            return check;
        }
    }

    public User getUserInfo() {
        User user = new User();
        return user;
    }
}